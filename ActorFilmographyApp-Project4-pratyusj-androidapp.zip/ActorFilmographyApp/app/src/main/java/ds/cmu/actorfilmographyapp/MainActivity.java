package ds.cmu.actorfilmographyapp;

//Name: Pratyush Jain
//Andrew ID: pratyusj

// Android imports
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

// RecyclerView imports
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

// Java imports for networking and JSON parsing
import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.List;

// JSON parsing
import org.json.JSONArray;
import org.json.JSONObject;

// Logging and custom adapter
import ds.cmu.actorfilmographyapp.Movie;
import ds.cmu.actorfilmographyapp.FilmographyAdapter;

public class MainActivity extends AppCompatActivity {

    private EditText actorNameInput;
    private Button searchButton;
    private RecyclerView filmographyRecyclerView;
    private FilmographyAdapter filmographyAdapter;
    private TextView noMoviesText;
    private TextView errorText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Initialize views
        actorNameInput = findViewById(R.id.actorNameInput);
        searchButton = findViewById(R.id.searchButton);
        filmographyRecyclerView = findViewById(R.id.filmographyRecyclerView);
        noMoviesText = findViewById(R.id.noMoviesText); // Get this from XML layout for empty search
        errorText = findViewById(R.id.errorText); // get this from XML layout for actor not found/no movies

        // Set up RecyclerView
        filmographyRecyclerView.setLayoutManager(new LinearLayoutManager(this));
        filmographyAdapter = new FilmographyAdapter(this, new ArrayList<>());
        filmographyRecyclerView.setAdapter(filmographyAdapter);

        // Set up search button click listener
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String actorName = actorNameInput.getText().toString().trim();
                if (actorName.isEmpty()) {
                    showErrorMessage("Please enter a valid actor name.");// Edittext data
                } else {
                    fetchFilmography(actorName);
                }
            }
        });
    }

    private void fetchFilmography(String actorName) {
        // Clear previous error messages
        clearMessages();

        // Execute network call on a background thread to avoid blocking the main UI thread
        new Thread(() -> {
            HttpURLConnection connection = null;
            try {
                // Construct the API URL with the actor's name
                String apiUrl = "https://redesigned-fiesta-46xjqvwxp97cq6jx-8080.app.github.dev/api/tmdb?actorName="
                        + URLEncoder.encode(actorName, "UTF-8");

                // Open connection to the URL
                URL url = new URL(apiUrl);
                connection = (HttpURLConnection) url.openConnection();
                connection.setRequestMethod("GET");
                connection.setRequestProperty("Accept", "application/json");

                // Get response code
                int responseCode = connection.getResponseCode();
                if (responseCode == HttpURLConnection.HTTP_OK) {
                    // Read response
                    InputStream inputStream = connection.getInputStream();
                    BufferedReader reader = new BufferedReader(new InputStreamReader(inputStream));
                    StringBuilder result = new StringBuilder();
                    String line;
                    while ((line = reader.readLine()) != null) {
                        result.append(line);
                    }

                    // Parse JSON response into a list of Movie objects
                    List<Movie> movies = parseMoviesJson(result.toString());

                    // Update RecyclerView on the main thread
                    runOnUiThread(() -> {
                        if (movies.isEmpty()) {
                            showNoMoviesMessage();
                        } else {
                            filmographyAdapter.updateData(movies);
                        }
                    });

                } else if (responseCode == HttpURLConnection.HTTP_BAD_REQUEST) {
                    runOnUiThread(() -> showErrorMessage("Invalid input. Please try again."));
                } else if (responseCode == HttpURLConnection.HTTP_INTERNAL_ERROR) {
                    runOnUiThread(() -> showErrorMessage("Server is currently unavailable. Please try later."));
                } else {
                    runOnUiThread(() -> showErrorMessage("Unexpected error occurred. Please try again."));
                }

            } catch (java.net.UnknownHostException e) {
                runOnUiThread(() -> showErrorMessage("Network error. Please check your internet connection."));
            } catch (Exception e) {
                Log.e("MainActivity", "Error fetching filmography", e);
                runOnUiThread(() -> showErrorMessage("An error occurred. Please try again."));
            } finally {
                if (connection != null) {
                    connection.disconnect();
                }
            }
        }).start();
    }

    private List<Movie> parseMoviesJson(String jsonResponse) {
        List<Movie> movies = new ArrayList<>();
        try {
            // Parse the root JSON object
            JSONObject root = new JSONObject(jsonResponse);

            // Check if third-party API returned invalid data
            if (!root.has("results") || root.getJSONArray("results").length() == 0) {
                return movies; // Return empty list
            }

            // Get the "results" array
            JSONArray resultsArray = root.getJSONArray("results");
            JSONObject actorObject = resultsArray.getJSONObject(0);
            JSONArray knownForArray = actorObject.getJSONArray("known_for");

            // Loop through the "known_for" array to extract movies
            for (int i = 0; i < knownForArray.length(); i++) {
                JSONObject movieObject = knownForArray.getJSONObject(i);

                // Extract movie details
                String title = movieObject.getString("title");
                String releaseDate = movieObject.optString("release_date", "N/A"); // Some entries may not have a release date
                String posterPath = movieObject.optString("poster_path", null);

                // Construct the full poster URL
                String posterUrl = posterPath != null ? "https://image.tmdb.org/t/p/w500" + posterPath : null;

                // Create a Movie object and add it to the list
                Movie movie = new Movie();
                movie.setTitle(title);
                movie.setReleaseDate(releaseDate);
                movie.setPosterUrl(posterUrl);

                movies.add(movie);
            }
        } catch (Exception e) {
            Log.e("MainActivity", "Error parsing JSON", e);
        }
        return movies;
    }

    private void showNoMoviesMessage() {
        filmographyRecyclerView.setVisibility(View.GONE);
        noMoviesText.setVisibility(View.VISIBLE);
        noMoviesText.setText("No movies found for the actor.");
    }

    private void showErrorMessage(String message) {
        filmographyRecyclerView.setVisibility(View.GONE);
        noMoviesText.setVisibility(View.GONE);
        errorText.setVisibility(View.VISIBLE);
        errorText.setText(message);
    }

    private void clearMessages() {
        noMoviesText.setVisibility(View.GONE);
        errorText.setVisibility(View.GONE);
        filmographyRecyclerView.setVisibility(View.VISIBLE);
    }
}

// Citation: Used help from GPT to create some parts of code: error message handling,getting movies in layout, parsing json and handle HTTP errors.