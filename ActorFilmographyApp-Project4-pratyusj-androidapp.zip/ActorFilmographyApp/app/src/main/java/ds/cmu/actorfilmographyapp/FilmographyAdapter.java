package ds.cmu.actorfilmographyapp;

//Name: Pratyush Jain
//Andrew ID: pratyusj

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import ds.cmu.actorfilmographyapp.Movie;

import java.util.List;


// Adapter class for managing showing the list of movies in a RecyclerView.

public class FilmographyAdapter extends RecyclerView.Adapter<FilmographyAdapter.ViewHolder> {

    private Context context;
    private List<Movie> movies;

    //Constructor for FilmographyAdapter.
    public FilmographyAdapter(Context context, List<Movie> movies) {
        this.context = context;
        this.movies = movies;
    }

    //Updates the data in the adapter and notifies the RecyclerView of changes
    public void updateData(List<Movie> movies) {
        this.movies.clear();
        this.movies.addAll(movies);
        notifyDataSetChanged();
    }


    //creates a ViewHolder for each item
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_movie, parent, false);
        return new ViewHolder(view);
    }


    //Binds the data to the item view at specified position.
    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Movie movie = movies.get(position);
        holder.movieTitle.setText(movie.getTitle());
        holder.releaseDate.setText(movie.getReleaseDate());
        Glide.with(context).load(movie.getPosterUrl()).into(holder.moviePoster);
    }

    @Override
    public int getItemCount() {
        return movies.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        ImageView moviePoster;
        TextView movieTitle, releaseDate;

//        for holding references

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            moviePoster = itemView.findViewById(R.id.moviePoster);
            movieTitle = itemView.findViewById(R.id.movieTitle);
            releaseDate = itemView.findViewById(R.id.releaseDate);
        }
    }
}

// Used help from chatGpt to create viewholder and hold it in place and onBind holder class.