package ds.cmu.actorfilm;

//Name: Pratyush Jain
//Andrew ID: pratyusj


import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

@WebServlet(name="TmdbServlet", value="/")
public class TmdbServlet extends HttpServlet {
    private static final String API_KEY = "37980da5e77e7e5c6dccd097149c5986"; //my api key

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        String actorName = req.getParameter("actorName"); // getiing actor name from input

        if (actorName == null || actorName.isEmpty()) { // Validate input
            resp.setStatus(HttpServletResponse.SC_BAD_REQUEST);
            DashboardServlet.logRequest(actorName, HttpServletResponse.SC_BAD_REQUEST, 0); // Log with 0 movies
            resp.sendError(HttpServletResponse.SC_BAD_REQUEST, "actorName parameter is required.");
            return;
        }

        String encodedActorName = URLEncoder.encode(actorName, StandardCharsets.UTF_8); // URL encode actor name, v imp!!

        try {
            String filmography = fetchFilmography(encodedActorName); // Fetch filmography data

            // Parse the filmography to calculate the number of movies
            JsonObject jsonResponse = JsonParser.parseString(filmography).getAsJsonObject(); //Parse json
            int movieCount = jsonResponse.getAsJsonArray("results").size();

            resp.setContentType("application/json");
            resp.setStatus(HttpServletResponse.SC_OK);// Success response
            DashboardServlet.logRequest(actorName, HttpServletResponse.SC_OK, movieCount); // Log with movie count
            PrintWriter writer = resp.getWriter();
            writer.write(filmography);
            writer.flush();
        } catch (Exception e) { // Handle exceptions
            resp.setStatus(HttpServletResponse.SC_INTERNAL_SERVER_ERROR);
            DashboardServlet.logRequest(actorName, HttpServletResponse.SC_INTERNAL_SERVER_ERROR, 0); // Log with 0 movies
            resp.sendError(HttpServletResponse.SC_INTERNAL_SERVER_ERROR, "Failed to fetch filmography.");
        }
    }


    private String fetchFilmography(String actorName) throws Exception {
        String searchUrl = "https://api.themoviedb.org/3/search/person?api_key=" + API_KEY + "&query=" + actorName; // Constructing actual query
        URL url = new URL(searchUrl);// Create URL object
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();
        connection.setRequestMethod("GET");
        connection.setRequestProperty("Accept", "application/json"); //accepting the json response

        try (BufferedReader reader = new BufferedReader(new InputStreamReader(connection.getInputStream()))) {
            StringBuilder result = new StringBuilder(); //storing response
            String line;
            while ((line = reader.readLine()) != null) {
                result.append(line);
            }
            JsonObject jsonResponse = JsonParser.parseString(result.toString()).getAsJsonObject();
            return jsonResponse.toString();// Return parsed JSON as string
        }
    }
}


// Cite: Used chatgpt to create parts of code, debugging and troubleshooting