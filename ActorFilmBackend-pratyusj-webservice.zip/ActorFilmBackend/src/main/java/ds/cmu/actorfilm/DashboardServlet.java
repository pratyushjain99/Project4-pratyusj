package ds.cmu.actorfilm;

//Name: Pratyush Jain
//        Andrew ID: pratyusj


import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import org.bson.Document;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


@WebServlet(name="DashboardServlet", value="/dashboard")
public class DashboardServlet extends HttpServlet {

    private static MongoCollection<Document> logsCollection; // basically mongoDB collection for logs

    static {
        try {
            MongoDatabase database = MongoClientManager.getDatabase(); // Initialize MongoDB database
            logsCollection = database.getCollection("api_logs"); // Get logs collection
        } catch (Exception e) {
            System.err.println("Failed to initialize MongoDB collection: " + e.getMessage()); // Log initialization error
        }
    }

    @Override
    public void init() throws ServletException {
        if (logsCollection == null) { // Reinitialize collection if null
            MongoDatabase database = MongoClientManager.getDatabase();
            logsCollection = database.getCollection("api_logs");
        }
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        StringBuilder htmlResponse = new StringBuilder("<html><body>");
        htmlResponse.append("<h1>API Request Logs Dashboard</h1>");

        // Add analytics data
        htmlResponse.append(calculateAnalytics());

        // Add logs table
        htmlResponse.append("<h2>Logs</h2><table border='1'><tr><th>#</th><th>Actor Name</th><th>Status Code</th><th>Pages(of movies) Returned</th><th>Timestamp</th></tr>");

        int counter = 1;
        if (logsCollection != null) {
            for (Document log : logsCollection.find()) {
                htmlResponse.append("<tr>")
                        .append("<td>").append(counter++).append("</td>")
                        .append("<td>").append(log.getString("actorName")).append("</td>")
                        .append("<td>").append(log.getInteger("statusCode")).append("</td>")
                        .append("<td>").append(log.getInteger("movieCount")).append("</td>")
                        .append("<td>").append(log.getString("timestamp")).append("</td>")
                        .append("</tr>");
            }
        } else {
            htmlResponse.append("<tr><td colspan='5'>No logs available. MongoDB is not initialized.</td></tr>");
        }

        htmlResponse.append("</table></body></html>");
        resp.setContentType("text/html");
        resp.getWriter().write(htmlResponse.toString());
    }



    public static void logRequest(String actorName, int statusCode, int movieCount) {


        if (logsCollection == null) {
            System.err.println("MongoDB logsCollection is null. Cannot log request.");// Log null collection error
            return;
        }

        Document logEntry = new Document()
                .append("actorName", actorName)
                .append("statusCode", statusCode)
                .append("movieCount", movieCount)
                .append("timestamp", java.time.LocalDateTime.now().toString());
        logsCollection.insertOne(logEntry);
    }

    private String calculateAnalytics() {
        StringBuilder analytics = new StringBuilder("<h2>Dashboard Analytics</h2><ul>");

        // Total number of requests
        long totalRequests = logsCollection.countDocuments();
        analytics.append("<li>Total Requests: ").append(totalRequests).append("</li>");

        // Total successful requests (status code 200)
        long successfulRequests = logsCollection.countDocuments(new Document("statusCode", HttpServletResponse.SC_OK));
        analytics.append("<li>Successful Requests: ").append(successfulRequests).append("</li>");

        // Most searched actor
        Document mostSearchedActor = logsCollection.aggregate(List.of(
                new Document("$group", new Document("_id", "$actorName").append("count", new Document("$sum", 1))),
                new Document("$sort", new Document("count", -1)),
                new Document("$limit", 1)
        )).first();
        if (mostSearchedActor != null) {
            analytics.append("<li>Most Searched Actor: ").append(mostSearchedActor.getString("_id"))
                    .append(" (").append(mostSearchedActor.getInteger("count")).append(" searches)</li>");
        }

        // Average movie count
        Document avgMovieCount = logsCollection.aggregate(List.of(
                new Document("$group", new Document("_id", null).append("avgMovies", new Document("$avg", "$movieCount")))
        )).first();
        if (avgMovieCount != null) {
            analytics.append("<li>Average Number of Pages (of Movies) Returned: ")
                    .append(avgMovieCount.getDouble("avgMovies")).append("</li>");
        }

        // Total unique actors searched
        long uniqueActors = logsCollection.distinct("actorName", String.class).into(new ArrayList<>()).size();
        analytics.append("<li>Unique Actors Searched: ").append(uniqueActors).append("</li>");

        // Success rate
        double successRate = totalRequests == 0 ? 0 : (double) successfulRequests / totalRequests * 100;
        analytics.append("<li>Success Rate: ").append(String.format("%.2f", successRate)).append("%</li>");

        analytics.append("</ul>");
        return analytics.toString();
    }


// Cite: Used chatgpt to create parts of code, debugging and troubleshooting
}
