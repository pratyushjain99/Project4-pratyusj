package ds.cmu.actorfilm;

//Name: Pratyush Jain
//Andrew ID: pratyusj

import com.mongodb.MongoClientSettings;
import com.mongodb.client.MongoClient;
import com.mongodb.client.MongoClients;
import com.mongodb.client.MongoDatabase;


// This entire file is self explanatory

// Cite: https://www.mongodb.com/docs/drivers/java/sync/v4.3/fundamentals/connection/connect/#std-label-connect-to-mongodb
// referred mongodb documentation to create this class

public class MongoClientManager {
    private static final String CONNECTION_STRING = "mongodb+srv://test:test@moviecluster.nfyhy.mongodb.net/?retryWrites=true&w=majority&appName=MovieCluster";
    private static MongoClient mongoClient;
    private static final String DATABASE_NAME = "ActorFilmApp";

    static {
        mongoClient = MongoClients.create(CONNECTION_STRING);
    }

    public static MongoDatabase getDatabase() {
        return mongoClient.getDatabase(DATABASE_NAME);
    }

    public static void closeClient() {
        if (mongoClient != null) {
            mongoClient.close();
        }
    }
}
